"""Legal corpus search page."""

import streamlit as st
from utils.display import show_response

st.title("Legal Search")
st.markdown("`GET /api/v1/legal/search`")
st.caption("Direct search of the civil law corpus — no supervisor graph invoked.")

client = st.session_state.get("client")
if not client:
    st.error("Configure API connection in the sidebar first.")
    st.stop()

query = st.text_input("Query", placeholder="Enter your question in Arabic or English...")
corpus = st.selectbox("Corpus", ["civil"], help="Only 'civil' is available today.")

if st.button("Search"):
    if not query.strip():
        st.error("Query is required.")
    else:
        with st.spinner("Searching legal corpus..."):
            status, body, elapsed = client.legal_search(query.strip(), corpus)
        show_response(status, body, elapsed)

        if status == 200:
            st.divider()

            # Metadata badges
            col1, col2 = st.columns(2)
            confidence = body.get("retrieval_confidence")
            if confidence is not None:
                col1.metric("Retrieval Confidence", f"{confidence:.2f}")
            from_cache = body.get("from_cache", False)
            col2.markdown(
                f"**Cache:** :{'green' if from_cache else 'gray'}[{'HIT' if from_cache else 'MISS'}]"
            )

            # Answer
            if body.get("answer"):
                st.subheader("Answer")
                st.markdown(body["answer"])

            # Sources
            if body.get("sources"):
                st.subheader("Sources")
                for src in body["sources"]:
                    st.markdown(f"- {src}")
